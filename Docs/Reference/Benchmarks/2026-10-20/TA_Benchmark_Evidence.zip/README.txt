TA Health Check benchmark evidence for TA and Master Class guide reuse
Measured 20 October 2026

The editable Word report is a standalone section ready to incorporate into the
TA user guide. Existing published guide files have not been changed.
Guide_Section_Source.txt provides reusable text and the numeric table.
TA_Benchmark_Results.json contains TA-only runs, hardware, environment and limits.
TA_Benchmark_Evidence.zip preserves original measurements and provenance, not
fresh test runs. It includes per-run metrics, 1-second resource telemetry,
module events, console logs, configurations, input hashes, diagnostics/manifests,
runtime/source inventories and the measurement harness.

MC reuse: use the same measured figures for the equivalent three-module workflow,
crediting TA Health Check and retaining measurement conditions. MC was not run.
This archive does not independently certify current TA/MC source equivalence.
Do not describe these figures as separately measured MC results or minimum specs.

Original generated reports and inputs remain under C:\Temp\B20\ta and the
synthetic dataset folders. They are omitted from this compact repository archive.
The all-product report remains at C:\Temp\B20\Benchmark_Report.html.
No application code, existing guides or CI/CD settings were changed for this report.
No further application benchmarks were run after the stop instruction.
