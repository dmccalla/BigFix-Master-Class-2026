"""Call the production engine with timing probes and automatic Word launch suppressed."""
import functools
import importlib
import json
import os
from pathlib import Path
import sys
import time

product, config = sys.argv[1:3]
app = Path('C:/Temp/B20/src/hc/Report Builder' if product == 'hc' else 'C:/Temp/B20/src/ta')
sys.path[:0] = [str(app / folder) for folder in ('', 'Build', 'App', 'Get', 'Inject')]
engine = importlib.import_module('build_health_check_report' if product == 'hc' else 'run_diagnostics')
profile = Path(os.environ['BENCH_MODULE_EVENTS'])


def record(event):
    with profile.open('a', encoding='utf-8') as handle:
        handle.write(json.dumps({'monotonic': time.perf_counter(), **event}) + '\n')


def timed(module):
    original = module.run

    @functools.wraps(original)
    def run(*args, **kwargs):
        start = time.perf_counter()
        record({'module': module.key, 'event': 'start'})
        try:
            result = original(*args, **kwargs)
        except BaseException:
            record({'module': module.key, 'event': 'end', 'result': 'failed', 'seconds': time.perf_counter() - start})
            raise
        record({'module': module.key, 'event': 'end', 'result': 'completed', 'seconds': time.perf_counter() - start})
        return result

    module.run = run


for module in engine.MODULES:
    timed(module)
if product == 'hc':
    engine.open_path = lambda path: print(f'BENCHMARK: automatic Word opening excluded: {path}', flush=True)
sys.argv = [str(app / ('Build/build_health_check_report.py' if product == 'hc' else 'App/run_diagnostics.py')), '--config', config, '--yes']
if product == 'hc':
    sys.argv.append('--no-scoring-pause')
raise SystemExit(engine.main())
