$ErrorActionPreference = 'Stop'
$system = Get-CimInstance Win32_ComputerSystem
$os = Get-CimInstance Win32_OperatingSystem
$cpu = @(Get-CimInstance Win32_Processor | Select-Object Name,Manufacturer,NumberOfCores,NumberOfLogicalProcessors,MaxClockSpeed,CurrentClockSpeed,L2CacheSize,L3CacheSize)
$memory = @(Get-CimInstance Win32_PhysicalMemory | Select-Object Capacity,Speed,ConfiguredClockSpeed,Manufacturer,PartNumber,FormFactor)
$disks = @(Get-CimInstance Win32_DiskDrive | Select-Object Model,MediaType,InterfaceType,Size)
$volumes = @(Get-CimInstance Win32_LogicalDisk -Filter 'DriveType=3' | Select-Object DeviceID,FileSystem,Size,FreeSpace)
$physical = @(Get-PhysicalDisk | Select-Object FriendlyName,MediaType,BusType,Size,HealthStatus)
$snapshot = [ordered]@{
    captured_utc = [DateTime]::UtcNow.ToString('o')
    system = [ordered]@{Manufacturer=$system.Manufacturer;Model=$system.Model;TotalPhysicalMemory=$system.TotalPhysicalMemory;NumberOfProcessors=$system.NumberOfProcessors;NumberOfLogicalProcessors=$system.NumberOfLogicalProcessors;HypervisorPresent=$system.HypervisorPresent}
    os = [ordered]@{Caption=$os.Caption;Version=$os.Version;BuildNumber=$os.BuildNumber;OSArchitecture=$os.OSArchitecture;TotalVisibleMemoryKiB=$os.TotalVisibleMemorySize;FreePhysicalMemoryKiB=$os.FreePhysicalMemory;LastBootUpTime=$os.LastBootUpTime.ToUniversalTime().ToString('o')}
    cpu = $cpu
    memory_modules = $memory
    disks = $disks
    physical_disks = $physical
    volumes = $volumes
    power_plan = @(powercfg /GETACTIVESCHEME)
}
$snapshot | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath 'C:\Users\duncan.mccalla\Documents\_Code\BigFix Health Check\Report Builder\Temp\benchmark_hardware.json' -Encoding UTF8
$snapshot.system | ConvertTo-Json
$cpu | ConvertTo-Json
$volumes | ConvertTo-Json
