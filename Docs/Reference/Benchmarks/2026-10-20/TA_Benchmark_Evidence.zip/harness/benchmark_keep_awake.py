"""Prevent unattended benchmark sleep without changing the power plan or display policy."""
import ctypes
from datetime import datetime, timezone
import json
from pathlib import Path
import time

root = Path('C:/Temp/B20')
kernel = ctypes.WinDLL('kernel32', use_last_error=True)
kernel.SetThreadExecutionState.argtypes = [ctypes.c_uint32]
kernel.SetThreadExecutionState.restype = ctypes.c_uint32
if not kernel.SetThreadExecutionState(0x80000001):
    raise ctypes.WinError(ctypes.get_last_error())
status = {'started_utc': datetime.now(timezone.utc).isoformat(), 'method': 'Thread execution request ES_CONTINUOUS | ES_SYSTEM_REQUIRED. Power plan and display timeout unchanged.'}
(root / 'sleep_inhibition.json').write_text(json.dumps(status, indent=2), encoding='utf-8')
print('Benchmark sleep prevention active. Power plan and display policy unchanged.', flush=True)
try:
    while True:
        final = root / 'ta/300k/a01/result.json'
        if final.exists() and json.loads(final.read_text(encoding='utf-8')).get('valid'):
            status['stop_reason'] = 'Last TA benchmark completed.'
            break
        files = [path for product in ('hc', 'ta') for path in (root / product).glob('*k/a*/resources.ndjson')]
        if files and time.time() - max(path.stat().st_mtime for path in files) > 120:
            status['stop_reason'] = 'No benchmark telemetry activity for two minutes.'
            break
        time.sleep(15)
finally:
    kernel.SetThreadExecutionState(0x80000000)
    status['ended_utc'] = datetime.now(timezone.utc).isoformat()
    (root / 'sleep_inhibition.json').write_text(json.dumps(status, indent=2), encoding='utf-8')
    print('Benchmark sleep prevention released.', flush=True)
