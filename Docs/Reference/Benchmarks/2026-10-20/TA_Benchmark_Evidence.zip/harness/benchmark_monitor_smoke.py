import json
import subprocess
import sys
import time
from benchmark_windows_metrics import Job, System, resume_suspended_process

system = System()
job = Job()
process = subprocess.Popen([sys.executable, '-c', 'import subprocess,sys,time; data=bytearray(64*1024*1024); p=subprocess.Popen([sys.executable,"-c","import time; b=bytearray(32*1024*1024); time.sleep(2)"]); p.wait(); time.sleep(1)'], creationflags=subprocess.CREATE_NO_WINDOW | 4)
job.assign(process)
resume_suspended_process(process.pid)
samples = []
while process.poll() is None:
    samples.append({**system.sample(), **job.sample()})
    time.sleep(.5)
samples.append({**system.sample(), **job.sample()})
assert process.returncode == 0
assert samples[-1]['tree_total_processes'] >= 2
assert max(row['tree_peak_job_commit_bytes'] for row in samples) > 96 * 1024**2
assert max(row['tree_private_bytes'] for row in samples) > 96 * 1024**2
assert samples[-1]['tree_cpu_seconds'] > 0
assert samples[-1]['tree_active_processes'] == 0
assert any(row.get('system_page_reads_per_sec') is not None for row in samples)
print(json.dumps({'passed': True, 'job_processes': samples[-1]['tree_total_processes'], 'peak_commit_mib': max(row['tree_peak_job_commit_bytes'] for row in samples)/1024**2, 'pdh_unavailable': system.pdh.errors, 'last': samples[-1]}, indent=2))
job.close()
