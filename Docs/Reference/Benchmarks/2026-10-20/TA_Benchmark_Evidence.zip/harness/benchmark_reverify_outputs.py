"""Recheck completed outputs after correcting report-file classification."""
import json
from pathlib import Path
import sys
from run_synthetic_benchmarks import verify_outputs, write_json

run = Path(sys.argv[1])
result = json.loads((run / 'result.json').read_text(encoding='utf-8'))
assert result['exit_code'] == 0 and not result['timed_out']
source = Path(f"C:/Temp/Synthetic_20261020_{result['endpoints'] // 1000}k")
evidence = json.loads((source / '_CAPABILITY_VALIDATION.json').read_text(encoding='utf-8'))
reporting = next(record for record in evidence['products'] if record['product'] == result['product'])['reporting']
verification = verify_outputs(result['product'], run / 'out', reporting, result['selected_modules'])
assert [event['module'] for event in result['module_timings'] if event['result'] == 'completed'] == result['selected_modules']
result.setdefault('verification_history', []).append(result['verification'])
result['verification'] = verification
result['valid'] = True
result['notes'].append('Post-build verification corrected to distinguish the combined Word report from module Mini Reports. Timed build and metrics unchanged.')
write_json(run / 'result.json', result)
print(json.dumps({'verified': str(run), 'source_rows': verification['loop_source_rows'], 'seconds': result['metrics']['elapsed_seconds'], 'valid': True}))
