"""Record exact runtimes and input identities outside timed build windows."""
import hashlib
import importlib.metadata
import json
from pathlib import Path
import platform
import subprocess
import sys

root = Path('C:/Temp/B20')
if len(sys.argv) > 1 and sys.argv[1] == '--runtime':
    print(json.dumps({'executable': sys.executable, 'python': sys.version, 'platform': platform.platform(),
                      'packages': {distribution.metadata['Name']: distribution.version for distribution in importlib.metadata.distributions()}}, indent=2))
    raise SystemExit(0)
apps = {'hc': root / 'src/hc/Report Builder', 'ta': root / 'src/ta'}
originals = {'hc': Path(__file__).resolve().parents[1], 'ta': Path('C:/Users/duncan.mccalla/Documents/_Code/TA Health Check')}
for product, app in apps.items():
    python = originals[product] / '.venv/Scripts/python.exe'
    runtime = subprocess.run([str(python), str(Path(__file__)), '--runtime'], capture_output=True, text=True, check=True)
    (root / f'{product}_runtime.json').write_text(runtime.stdout, encoding='utf-8')
    commit = subprocess.run(['git', '-C', str(app), 'rev-parse', 'HEAD'], capture_output=True, text=True, check=True).stdout.strip()
    sources = {}
    for folder in ('Build', 'App', 'Get', 'Inject', 'Lib', 'Templates', 'Config'):
        for path in (app / folder).rglob('*'):
            if path.is_file() and '__pycache__' not in path.parts and path.suffix not in {'.pyc', '.pyo'}:
                with path.open('rb') as handle:
                    sources[str(path.relative_to(app))] = hashlib.file_digest(handle, 'sha256').hexdigest()
    (root / f'{product}_source_inventory.json').write_text(json.dumps({'commit': commit, 'files': sources}, indent=2), encoding='utf-8')
print('Recorded both runtimes and code snapshots.')
