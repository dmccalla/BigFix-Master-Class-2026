"""Dependency-free Windows job and system telemetry for local benchmarks."""
import ctypes as C
from ctypes import wintypes as W
import os
import time

K = C.WinDLL('kernel32', use_last_error=True)
P = C.WinDLL('psapi', use_last_error=True)
SIZE = C.c_size_t
U64 = C.c_ulonglong
I64 = C.c_longlong


class IO(C.Structure):
    _fields_ = [(name, U64) for name in ('read_ops', 'write_ops', 'other_ops', 'read_bytes', 'write_bytes', 'other_bytes')]


class Accounting(C.Structure):
    _fields_ = [(name, I64) for name in ('user', 'kernel', 'period_user', 'period_kernel')] + [(name, W.DWORD) for name in ('page_faults', 'total_processes', 'active_processes', 'terminated_processes')]


class AccountIO(C.Structure):
    _fields_ = [('accounting', Accounting), ('io', IO)]


class BasicLimit(C.Structure):
    _fields_ = [('process_time', I64), ('job_time', I64), ('flags', W.DWORD), ('min_ws', SIZE), ('max_ws', SIZE), ('active_limit', W.DWORD), ('affinity', SIZE), ('priority', W.DWORD), ('scheduling', W.DWORD)]


class ExtendedLimit(C.Structure):
    _fields_ = [('basic', BasicLimit), ('io', IO), ('process_memory_limit', SIZE), ('job_memory_limit', SIZE), ('peak_process_commit', SIZE), ('peak_job_commit', SIZE)]


class ProcessIDs(C.Structure):
    _fields_ = [('assigned', W.DWORD), ('count', W.DWORD), ('ids', SIZE * 2048)]


class ProcessMemory(C.Structure):
    _fields_ = [('cb', W.DWORD), ('page_fault_count', W.DWORD)] + [(name, SIZE) for name in ('peak_rss', 'rss', 'peak_paged', 'paged', 'peak_nonpaged', 'nonpaged', 'pagefile', 'peak_pagefile', 'private')]


class Performance(C.Structure):
    _fields_ = [('cb', W.DWORD)] + [(name, SIZE) for name in ('commit_total', 'commit_limit', 'commit_peak', 'physical_total', 'physical_available', 'system_cache', 'kernel_total', 'kernel_paged', 'kernel_nonpaged', 'page_size')] + [(name, W.DWORD) for name in ('handle_count', 'process_count', 'thread_count')]


class Power(C.Structure):
    _fields_ = [('ac', C.c_ubyte), ('battery_flag', C.c_ubyte), ('battery_percent', C.c_ubyte), ('status', C.c_ubyte), ('battery_seconds', W.DWORD), ('battery_full_seconds', W.DWORD)]


K.CreateJobObjectW.argtypes = [C.c_void_p, W.LPCWSTR]
K.CreateJobObjectW.restype = W.HANDLE
K.SetInformationJobObject.argtypes = [W.HANDLE, C.c_int, C.c_void_p, W.DWORD]
K.AssignProcessToJobObject.argtypes = [W.HANDLE, W.HANDLE]
K.QueryInformationJobObject.argtypes = [W.HANDLE, C.c_int, C.c_void_p, W.DWORD, C.c_void_p]
K.TerminateJobObject.argtypes = [W.HANDLE, W.UINT]
K.OpenProcess.argtypes = [W.DWORD, W.BOOL, W.DWORD]
K.OpenProcess.restype = W.HANDLE
K.CloseHandle.argtypes = [W.HANDLE]
K.GetSystemTimes.argtypes = [C.POINTER(U64), C.POINTER(U64), C.POINTER(U64)]
K.GetSystemPowerStatus.argtypes = [C.POINTER(Power)]
P.GetPerformanceInfo.argtypes = [C.POINTER(Performance), W.DWORD]
P.GetProcessMemoryInfo.argtypes = [W.HANDLE, C.POINTER(ProcessMemory), W.DWORD]


class ThreadEntry(C.Structure):
    _fields_ = [('size', W.DWORD), ('usage', W.DWORD), ('thread_id', W.DWORD), ('owner_pid', W.DWORD), ('base_priority', W.LONG), ('delta_priority', W.LONG), ('flags', W.DWORD)]


def resume_suspended_process(pid):
    """Resume the primary thread only after the process joins its accounting job."""
    K.CreateToolhelp32Snapshot.argtypes = [W.DWORD, W.DWORD]
    K.CreateToolhelp32Snapshot.restype = W.HANDLE
    K.Thread32First.argtypes = [W.HANDLE, C.POINTER(ThreadEntry)]
    K.Thread32Next.argtypes = [W.HANDLE, C.POINTER(ThreadEntry)]
    K.OpenThread.argtypes = [W.DWORD, W.BOOL, W.DWORD]
    K.OpenThread.restype = W.HANDLE
    K.ResumeThread.argtypes = [W.HANDLE]
    snapshot = K.CreateToolhelp32Snapshot(4, 0)
    checked(snapshot and snapshot != C.c_void_p(-1).value)
    entry = ThreadEntry()
    entry.size = C.sizeof(entry)
    try:
        more = K.Thread32First(snapshot, C.byref(entry))
        while more:
            if entry.owner_pid == pid:
                thread = K.OpenThread(2, False, entry.thread_id)
                checked(thread)
                try:
                    checked(K.ResumeThread(thread) != -1)
                finally:
                    K.CloseHandle(thread)
                return
            more = K.Thread32Next(snapshot, C.byref(entry))
        raise RuntimeError(f'No primary thread found for benchmark process {pid}')
    finally:
        K.CloseHandle(snapshot)


def checked(ok):
    if not ok:
        raise C.WinError(C.get_last_error())


class Job:
    def __init__(self):
        self.handle = K.CreateJobObjectW(None, None)
        checked(self.handle)
        limits = ExtendedLimit()
        limits.basic.flags = 0x2000  # Kill only this benchmark's descendants on harness failure.
        checked(K.SetInformationJobObject(self.handle, 9, C.byref(limits), C.sizeof(limits)))
        self.previous_cpu = 0.0
        self.previous_time = time.perf_counter()

    def assign(self, process):
        checked(K.AssignProcessToJobObject(self.handle, int(process._handle)))

    def query(self, number, structure):
        value = structure()
        checked(K.QueryInformationJobObject(self.handle, number, C.byref(value), C.sizeof(value), None))
        return value

    def sample(self):
        now = time.perf_counter()
        account = self.query(8, AccountIO)
        limits = self.query(9, ExtendedLimit)
        ids = self.query(3, ProcessIDs)
        rss = private = 0
        inaccessible = 0
        for pid in ids.ids[:ids.count]:
            handle = K.OpenProcess(0x410, False, int(pid))
            if not handle:
                inaccessible += 1
                continue
            try:
                memory = ProcessMemory()
                memory.cb = C.sizeof(memory)
                if P.GetProcessMemoryInfo(handle, C.byref(memory), memory.cb):
                    rss += memory.rss
                    private += memory.private
                else:
                    inaccessible += 1
            finally:
                K.CloseHandle(handle)
        cpu = (account.accounting.user + account.accounting.kernel) / 1e7
        cores = max(0.0, cpu - self.previous_cpu) / max(now - self.previous_time, 1e-6)
        self.previous_cpu, self.previous_time = cpu, now
        return {
            'tree_cpu_seconds': cpu, 'tree_cpu_core_equivalents': cores,
            'tree_cpu_percent_machine': cores / os.cpu_count() * 100,
            'tree_private_bytes': private, 'tree_working_set_sum_bytes': rss,
            'tree_peak_job_commit_bytes': limits.peak_job_commit,
            'tree_peak_single_process_commit_bytes': limits.peak_process_commit,
            'tree_total_processes': account.accounting.total_processes,
            'tree_active_processes': account.accounting.active_processes,
            'tree_process_sample_misses': inaccessible,
            'tree_read_bytes': account.io.read_bytes, 'tree_write_bytes': account.io.write_bytes,
        }

    def terminate(self):
        checked(K.TerminateJobObject(self.handle, 1460))

    def close(self):
        K.CloseHandle(self.handle)


class System:
    def __init__(self):
        self.previous_times = None
        self.pdh = Counters()

    def sample(self):
        perf = Performance()
        perf.cb = C.sizeof(perf)
        checked(P.GetPerformanceInfo(C.byref(perf), perf.cb))
        idle, kernel, user = U64(), U64(), U64()
        checked(K.GetSystemTimes(C.byref(idle), C.byref(kernel), C.byref(user)))
        current = (idle.value, kernel.value + user.value)
        cpu = None
        if self.previous_times:
            total = current[1] - self.previous_times[1]
            if total:
                cpu = max(0.0, min(100.0, 100 * (1 - (current[0] - self.previous_times[0]) / total)))
        self.previous_times = current
        power = Power()
        checked(K.GetSystemPowerStatus(C.byref(power)))
        free = U64()
        total_disk = U64()
        disk_free = U64()
        checked(K.GetDiskFreeSpaceExW(W.LPCWSTR('C:\\'), C.byref(free), C.byref(total_disk), C.byref(disk_free)))
        return {
            'system_cpu_percent': cpu,
            'system_available_ram_bytes': perf.physical_available * perf.page_size,
            'system_total_ram_bytes': perf.physical_total * perf.page_size,
            'system_commit_bytes': perf.commit_total * perf.page_size,
            'system_commit_limit_bytes': perf.commit_limit * perf.page_size,
            'system_commit_percent': perf.commit_total / perf.commit_limit * 100,
            'system_process_count': perf.process_count,
            'c_drive_available_bytes': free.value, 'ac_power_status': power.ac,
            'battery_percent': power.battery_percent, **self.pdh.sample(),
        }


class CounterValue(C.Structure):
    _fields_ = [('status', W.DWORD), ('value', C.c_double)]


class Counters:
    paths = {
        'system_page_reads_per_sec': r'\Memory\Page Reads/sec',
        'system_pages_input_per_sec': r'\Memory\Pages Input/sec',
        'system_disk_queue_length': r'\PhysicalDisk(_Total)\Avg. Disk Queue Length',
        'system_disk_read_bytes_per_sec': r'\PhysicalDisk(_Total)\Disk Read Bytes/sec',
        'system_disk_write_bytes_per_sec': r'\PhysicalDisk(_Total)\Disk Write Bytes/sec',
        'system_cpu_percent_max_frequency': r'\Processor Information(_Total)\% of Maximum Frequency',
    }

    def __init__(self):
        self.lib = C.WinDLL('pdh')
        self.lib.PdhOpenQueryW.argtypes = [W.LPCWSTR, SIZE, C.POINTER(W.HANDLE)]
        self.lib.PdhAddEnglishCounterW.argtypes = [W.HANDLE, W.LPCWSTR, SIZE, C.POINTER(W.HANDLE)]
        self.lib.PdhCollectQueryData.argtypes = [W.HANDLE]
        self.lib.PdhGetFormattedCounterValue.argtypes = [W.HANDLE, W.DWORD, C.c_void_p, C.POINTER(CounterValue)]
        self.query = W.HANDLE()
        self.handles = {}
        self.errors = {}
        status = self.lib.PdhOpenQueryW(None, 0, C.byref(self.query))
        if status:
            raise OSError(f'PdhOpenQueryW failed: {status:#x}')
        for key, path in self.paths.items():
            handle = W.HANDLE()
            status = self.lib.PdhAddEnglishCounterW(self.query, path, 0, C.byref(handle))
            if status:
                self.errors[key] = f'{status:#x}'
            else:
                self.handles[key] = handle
        self.lib.PdhCollectQueryData(self.query)

    def sample(self):
        self.lib.PdhCollectQueryData(self.query)
        result = {}
        for key, handle in self.handles.items():
            value = CounterValue()
            status = self.lib.PdhGetFormattedCounterValue(handle, 0x200, None, C.byref(value))
            result[key] = value.value if not status and value.status in (0, 1) else None
        return result
