"""Serial full-engine benchmarks with isolated inputs and Windows job accounting."""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import shutil
import statistics
import subprocess
import sys
import time
import zipfile

from benchmark_windows_metrics import Job, System, resume_suspended_process

ROOT = Path('C:/Temp/B20')
HERE = Path(__file__).resolve().parent
MAIN = HERE.parent
PRODUCTS = {
    'hc': (ROOT / 'src/hc/Report Builder', MAIN / '.venv/Scripts/python.exe', 'e4338b6'),
    'ta': (ROOT / 'src/ta', MAIN.parent.parent / 'TA Health Check/.venv/Scripts/python.exe', 'bfe6615'),
}
MODULES = ['deployment', 'dashboard', 'dbinfo', 'filldb', 'perfmon', 'loop', 'capacity', 'deploy_info', 'client_settings_suggester', 'server_logs', 'findings', 'release_intelligence', 'strengths', 'key_risks', 'hc_analyzer']


def utc():
    return datetime.now(timezone.utc).isoformat()


def write_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, default=str) + '\n', encoding='utf-8')


def sha(path):
    with path.open('rb') as handle:
        return hashlib.file_digest(handle, 'sha256').hexdigest()


def percentile(values, fraction):
    values = sorted(value for value in values if value is not None)
    return values[min(len(values) - 1, int((len(values) - 1) * fraction))] if values else None


def config_for(product, size, data, output):
    app, _, _ = PRODUCTS[product]
    loop = data / 'Client_loop'
    inputs = {
        'loop': {'input_xlsx': str(next(loop.glob('Client_Loop_*.xml'))), 'deployment_info_folder': str(data / 'Deployment_Information'),
                 'top_offenders_file': str(loop / 'top10-query-results.csv'), 'udp_notifications_file': str(next(loop.glob('UDP_Notifications_*.xml')))},
        'perfmon': {'blg_path': str(next((data / 'Perfmon').glob('*.blg')))},
        'filldb': {'input_csv': str(next((data / 'Logs/FillDB_Performance').glob('*.csv')))},
    }
    config = {'modules': MODULES if product == 'hc' else ['loop', 'perfmon', 'filldb'],
              'data_root': str(data), 'output_folder': str(output), 'run_name': f'B{size}',
              'customer_name': f'B{size}', 'assessment_start_date': '2026-07-31', 'assessment_end_date': '2026-07-31',
              'inject': product == 'hc', 'inputs': inputs}
    if product == 'hc':
        config['template'] = str(max((app / 'Templates').glob('BigFix_Health_Check_Template_*.dotx')))
        inputs['deployment'] = {'log_path': str(next((data / 'Deployment_Overview_Dashboard').glob('*.xml')))}
        inputs['dashboard'] = {'log_path': str(next((data / 'Deployment_Healthcheck_Dashboard').glob('*.xml')))}
        inputs['dbinfo'] = {'input_path': str(next((data / 'SQL/SQL_Information').glob('*sql_database_info.csv')))}
        inputs['release_intelligence'] = {'release_intelligence_evidence': str(next((data / 'Release_Intelligence').glob('release_intelligence_*.json')))}
        for module in ('capacity', 'client_settings_suggester', 'findings', 'strengths', 'key_risks', 'hc_analyzer'):
            inputs[module] = {'data_folder': str(data)}
        inputs['deploy_info'] = {'log_folder': str(data / 'Deployment_Information')}
        inputs['server_logs'] = {'log_folder': str(data / 'Logs')}
    return config


def verify_outputs(product, output, expected_reporting, modules):
    from openpyxl import load_workbook
    files = [path for path in output.rglob('*') if path.is_file()]
    word = [path for path in files if path.suffix == '.docx']
    excel = [path for path in files if path.suffix == '.xlsx']
    png = [path for path in files if path.suffix == '.png']
    assert len(word) >= (1 if product == 'hc' else 3), 'Missing Word outputs'
    assert len(excel) >= (3 if product == 'hc' else 2) and len(png) >= 3, 'Missing workbook/chart outputs'
    final = [path for path in word if path.name.endswith('_Report.docx') and path.parent.parent == output]
    if product == 'hc':
        assert len(final) == 1, f'Expected one combined report, got {final}'
    for path in word:
        with zipfile.ZipFile(path) as archive:
            assert archive.testzip() is None, path
            assert archive.getinfo('word/document.xml').file_size > 1000, path
    loop_book = next(path for path in excel if path.name.endswith('_Client_Loop.xlsx'))
    book = load_workbook(loop_book, read_only=True, data_only=True)
    try:
        count = book['Source Data'].max_row - 1
        assert count == expected_reporting, (count, expected_reporting)
        assert {'Evaluation Frequency', 'Min Analysis Interval', 'UDP Issues by Relay', 'UDP Issues by Subnet', 'Polling by Relay', 'Polling by Subnet'} <= set(book.sheetnames)
    finally:
        book.close()
    return {'passed': True, 'docx_count': len(word), 'xlsx_count': len(excel), 'png_count': len(png),
            'loop_source_rows': count, 'combined_report': str(final[0]) if final else None,
            'output_bytes': sum(path.stat().st_size for path in files),
            'output_files': [{'path': str(path.relative_to(output)), 'bytes': path.stat().st_size} for path in files]}


def run_one(product, size, attempt):
    app, python, commit = PRODUCTS[product]
    run = ROOT / product / f'{size}k' / f'a{attempt:02d}'
    if run.exists():
        raise ValueError(f'Refusing to overwrite benchmark attempt: {run}')
    run.mkdir(parents=True)
    source = Path(f'C:/Temp/Synthetic_20261020_{size}k')
    data, output = run / 'in', run / 'out'
    prep_start = time.perf_counter()
    shutil.copytree(source, data, ignore=shutil.ignore_patterns('_validation', '__pycache__'))
    output.mkdir()
    inputs_before = {str(path.relative_to(data)): {'sha256': sha(path), 'bytes': path.stat().st_size} for path in data.rglob('*') if path.is_file()}
    write_json(run / 'input_inventory.json', inputs_before)
    config = config_for(product, size, data, output)
    write_json(run / 'config.json', config)
    prep_seconds = time.perf_counter() - prep_start
    monitor = System()
    rows = []
    with (run / 'resources.ndjson').open('w', encoding='utf-8') as telemetry:
        def sample(phase, job=None, start=None):
            row = {'utc': utc(), 'monotonic': time.perf_counter(), 'phase': phase, **monitor.sample()}
            if start is not None:
                row['elapsed_seconds'] = time.perf_counter() - start
            if job:
                row.update(job.sample())
            telemetry.write(json.dumps(row) + '\n')
            telemetry.flush()
            rows.append(row)
            return row
        print(f'BASELINE {product} {size}k: 15 seconds', flush=True)
        for _ in range(15):
            sample('baseline')
            time.sleep(1)
        job = Job()
        started = time.perf_counter()
        wall_start = utc()
        env = {**os.environ, 'PYTHONUTF8': '1', 'PYTHONIOENCODING': 'utf-8', 'PYTHONDONTWRITEBYTECODE': '1',
               'BENCH_MODULE_EVENTS': str(run / 'module_events.ndjson')}
        print(f'START {product} {size}k: {wall_start}', flush=True)
        timed_out = False
        with (run / 'console.log').open('w', encoding='utf-8') as console:
            process = subprocess.Popen([str(python), str(HERE / 'benchmark_engine_entry.py'), product, str(run / 'config.json')],
                                       cwd=app, env=env, stdout=console, stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL,
                                       creationflags=subprocess.CREATE_NO_WINDOW | 4)
            try:
                job.assign(process)
                resume_suspended_process(process.pid)
                last_progress = started
                while process.poll() is None:
                    sample('build', job, started)
                    if time.perf_counter() - last_progress >= 45:
                        row = rows[-1]
                        events = run / 'module_events.ndjson'
                        current = json.loads(events.read_text(encoding='utf-8').splitlines()[-1]) if events.exists() else {}
                        print(json.dumps({'progress': product, 'endpoints': size * 1000, 'elapsed_seconds': round(time.perf_counter() - started), 'module': current.get('module', 'configuration'),
                                          'private_gib': round(row['tree_private_bytes'] / 2**30, 2), 'available_ram_gib': round(row['system_available_ram_bytes'] / 2**30, 2)}), flush=True)
                        last_progress = time.perf_counter()
                    if time.perf_counter() - started > 7200:
                        timed_out = True
                        job.terminate()
                        break
                    time.sleep(1)
                process.wait(timeout=30)
                ended = time.perf_counter()
                final_sample = sample('build_end', job, started)
                if final_sample['tree_active_processes']:
                    for _ in range(10):
                        time.sleep(1)
                        final_sample = sample('drain', job, started)
                        if not final_sample['tree_active_processes']:
                            break
                if final_sample['tree_active_processes']:
                    job.terminate()
            finally:
                if process.poll() is None:
                    job.terminate()
                    process.wait(timeout=30)
                job.close()
        for _ in range(5):
            sample('after')
            time.sleep(1)
    build = [row for row in rows if row['phase'] in ('build', 'build_end')]
    baseline = [row for row in rows if row['phase'] == 'baseline']
    metrics = {
        'elapsed_seconds': ended - started,
        'cpu_seconds': final_sample['tree_cpu_seconds'],
        'cpu_average_core_equivalents': final_sample['tree_cpu_seconds'] / (ended - started),
        'cpu_average_percent_machine': final_sample['tree_cpu_seconds'] / (ended - started) / os.cpu_count() * 100,
        'peak_tree_commit_gib': max(row['tree_peak_job_commit_bytes'] for row in build) / 2**30,
        'peak_tree_private_sampled_gib': max(row['tree_private_bytes'] for row in build) / 2**30,
        'peak_tree_working_set_sum_sampled_gib': max(row['tree_working_set_sum_bytes'] for row in build) / 2**30,
        'min_available_ram_gib': min(row['system_available_ram_bytes'] for row in build) / 2**30,
        'baseline_available_ram_gib': statistics.median(row['system_available_ram_bytes'] for row in baseline) / 2**30,
        'baseline_cpu_percent': statistics.mean(row['system_cpu_percent'] for row in baseline if row['system_cpu_percent'] is not None),
        'system_cpu_p95_percent': percentile([row['system_cpu_percent'] for row in build], .95),
        'system_commit_peak_gib': max(row['system_commit_bytes'] for row in build) / 2**30,
        'system_commit_peak_percent': max(row['system_commit_percent'] for row in build),
        'system_page_reads_p95_per_sec': percentile([row.get('system_page_reads_per_sec') for row in build], .95),
        'system_disk_queue_p95': percentile([row.get('system_disk_queue_length') for row in build], .95),
        'tree_read_gib': final_sample['tree_read_bytes'] / 2**30,
        'tree_write_gib': final_sample['tree_write_bytes'] / 2**30,
        'tree_total_processes': final_sample['tree_total_processes'],
        'process_sampling_misses': sum(row['tree_process_sample_misses'] for row in build),
        'available_disk_before_gib': baseline[-1]['c_drive_available_bytes'] / 2**30,
        'available_disk_after_gib': rows[-1]['c_drive_available_bytes'] / 2**30,
        'ac_power_states': sorted({row['ac_power_status'] for row in build}),
    }
    events_path = run / 'module_events.ndjson'
    events = [json.loads(line) for line in events_path.read_text(encoding='utf-8').splitlines()] if events_path.exists() else []
    completed = [event for event in events if event['event'] == 'end']
    verification = {'passed': False}
    if not process.returncode and not timed_out:
        try:
            evidence = json.loads((source / '_CAPABILITY_VALIDATION.json').read_text(encoding='utf-8'))
            reporting = next(record for record in evidence['products'] if record['product'] == product)['reporting']
            verification = verify_outputs(product, output, reporting, config['modules'])
            assert [event['module'] for event in completed if event['result'] == 'completed'] == config['modules'], 'Not every selected module completed'
        except Exception as exc:
            verification = {'passed': False, 'error': repr(exc)}
    result = {'product': product, 'endpoints': size * 1000, 'attempt': attempt, 'code_commit': commit,
              'started_utc': wall_start, 'ended_utc': utc(), 'exit_code': process.returncode, 'timed_out': timed_out,
              'metrics': metrics, 'module_timings': completed, 'selected_modules': config['modules'],
              'preparation_seconds_excluded': prep_seconds, 'telemetry_sample_interval_seconds': 1,
              'unavailable_pdh_counters': monitor.pdh.errors, 'verification': verification,
              'valid': process.returncode == 0 and verification['passed'] and not timed_out,
              'notes': ['Fresh Python process and fresh private input copy; Windows file cache is not flushed.',
                        'Measured build includes engine input discovery, data analysis, chart rendering, Excel and Word output.',
                        'Human module selection, consultant review pauses, output verification and opening Word are excluded.',
                        'Working-set sum can double-count shared pages; job peak commit is separately recorded.',
                        'System paging and disk counters include background applications.']}
    write_json(run / 'result.json', result)
    print(json.dumps({'COMPLETE': product, 'endpoints': size * 1000, 'valid': result['valid'], 'exit_code': process.returncode,
                      'seconds': round(metrics['elapsed_seconds'], 1), 'peak_commit_gib': round(metrics['peak_tree_commit_gib'], 2),
                      'verification': {key: value for key, value in verification.items() if key != 'output_files'}}), flush=True)
    if not result['valid']:
        print('\n'.join((run / 'console.log').read_text(encoding='utf-8').splitlines()[-32:]), flush=True)
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('product', choices=PRODUCTS)
    parser.add_argument('--sizes', nargs='+', type=int, default=[50, 100, 150, 200, 250, 300])
    parser.add_argument('--attempt', type=int, default=1)
    args = parser.parse_args()
    ROOT.mkdir(exist_ok=True)
    shutil.copy2(HERE / 'benchmark_hardware.json', ROOT / 'hardware.json')
    write_json(ROOT / 'method.json', {'date': '2026-10-20', 'ordered_sizes_k': [50,100,150,200,250,300],
                                     'order': 'All main builder runs, followed by TA runs; no concurrent benchmark builds.',
                                     'sampling': 'Windows job accounting plus one-second system and live process-tree samples.',
                                     'baseline_seconds': 15, 'source_snapshots': {key: str(value[0]) for key, value in PRODUCTS.items()},
                                     'repetitions': 1, 'limits': 'One workstation, one measured pass per product/size, warm filesystem caches possible, no CPU/RAM limits imposed.'})
    for size in args.sizes:
        result = run_one(args.product, size, args.attempt)
        if not result['valid']:
            raise SystemExit(1)


if __name__ == '__main__':
    main()
