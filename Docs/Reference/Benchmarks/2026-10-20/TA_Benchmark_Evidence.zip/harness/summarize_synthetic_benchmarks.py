"""Build a portable HTML benchmark report, plots and machine-readable results."""
from __future__ import annotations

import base64
from collections import defaultdict
from datetime import datetime
import html
import json
import math
from pathlib import Path
import shutil
import statistics
from zoneinfo import ZoneInfo

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT = Path('C:/Temp/B20')
SIZES = [50000, 100000, 150000, 200000, 250000, 300000]
COLORS = {'hc': '#0057b8', 'ta': '#00856a'}
NAMES = {'hc': 'Main Report Builder', 'ta': 'TA Health Check'}
MODULE_NAMES = {'deployment': 'Deployment Overview', 'dashboard': 'Health Dashboard', 'dbinfo': 'SQL Information',
                'filldb': 'FillDB', 'perfmon': 'PerfMon', 'loop': 'Client Performance', 'capacity': 'Server Capacity',
                'deploy_info': 'Deployment Information', 'client_settings_suggester': 'Client Settings Suggestions',
                'server_logs': 'Server Logs', 'findings': 'Findings and Scoring', 'release_intelligence': 'Release Intelligence',
                'strengths': "What's Working Well", 'key_risks': 'What Needs Attention', 'hc_analyzer': 'Supporting Analysis'}


def load(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def stats(values):
    clean = [value for value in values if value is not None]
    return {'min': min(clean), 'max': max(clean), 'mean': statistics.mean(clean)} if clean else None


def main():
    harness = ROOT / 'harness'
    harness.mkdir(exist_ok=True)
    for name in ('benchmark_windows_metrics.py', 'benchmark_engine_entry.py', 'run_synthetic_benchmarks.py', 'benchmark_runtime_inventory.py', 'benchmark_hardware.ps1', 'benchmark_monitor_smoke.py', 'benchmark_reverify_outputs.py', 'benchmark_keep_awake.py', 'summarize_synthetic_benchmarks.py', 'verify_benchmark_report.py'):
        shutil.copy2(Path(__file__).with_name(name), harness / name)
    attempts = [load(path) | {'evidence_folder': str(path.parent)} for product in ('hc', 'ta') for path in (ROOT / product).glob('*k/a*/result.json')]
    selected = {}
    for result in attempts:
        key = result['product'], result['endpoints']
        if result['valid'] and (key not in selected or result['attempt'] > selected[key]['attempt']):
            selected[key] = result
    ordered = [selected[product, size] for product in ('hc', 'ta') for size in SIZES if (product, size) in selected]
    complete = len(ordered) == 12
    input_comparisons = []
    for size in SIZES:
        if ('hc', size) in selected and ('ta', size) in selected:
            inventories = {product: load(Path(selected[product, size]['evidence_folder']) / 'input_inventory.json') for product in ('hc', 'ta')}
            differences = [name for name in sorted(inventories['hc'].keys() | inventories['ta'].keys()) if inventories['hc'].get(name) != inventories['ta'].get(name)]
            input_comparisons.append({'endpoints': size, 'identical_inputs_across_products': not differences, 'different_files': differences})
    for result in ordered:
        events = result['module_timings']
        samples = [json.loads(line) for line in (Path(result['evidence_folder']) / 'resources.ndjson').read_text(encoding='utf-8').splitlines()]
        build = [row for row in samples if row['phase'] in ('build', 'build_end')]
        result['background_system_metrics'] = {key: stats([row.get(key) for row in build]) for key in ('system_cpu_percent', 'system_page_reads_per_sec', 'system_pages_input_per_sec', 'system_disk_queue_length', 'system_disk_read_bytes_per_sec', 'system_disk_write_bytes_per_sec', 'system_cpu_percent_max_frequency')}
        for index, event in enumerate(events):
            # End events record the actual duration of the unmodified module pipeline.
            beginning = event['monotonic'] - event['seconds']
            during = [row for row in build if beginning <= row['monotonic'] <= event['monotonic']]
            event['peak_live_private_sampled_gib'] = max((row['tree_private_bytes'] for row in during), default=0) / 2**30
    hardware = load(ROOT / 'hardware.json')
    if (ROOT / 'hardware_gpu.json').exists():
        hardware['graphics'] = load(ROOT / 'hardware_gpu.json')
    runtime = {product: load(ROOT / f'{product}_runtime.json') for product in ('hc', 'ta')}
    summary = {'complete': complete, 'hardware': hardware, 'method': load(ROOT / 'method.json'), 'runtime': runtime,
               'input_comparisons': input_comparisons,
               'valid_runs': ordered, 'excluded_attempts': [result for result in attempts if not result['valid']],
               'interpretation': ['These are source-Python production-engine builds, not packaged executable or UI responsiveness benchmarks.',
                                  'Each size has one measured run per product. Caches were not flushed. Ascending size and product order may affect timings.',
                                  'Input copies are prepared outside the timer and can warm the filesystem cache. Cold storage reads and network-share performance are not measured.',
                                  'Main builder runs 15 supported modules and creates a combined Word report. TA runs its three module pipelines. Total runtimes represent different scopes.',
                                  'PerfMon, activity logs, SQL and hardware examples remain fixed; endpoint records and UDP/setting distributions grow.',
                                  'The fixed PerfMon fixture has 360 readings and 232 counters. Longer or larger PerfMon captures, larger logs and larger property catalogues can require additional time and memory.',
                                  'The supplied friendly Top 10 CSV is used, as selected by the ordinary folder discovery. Raw timing XML aggregation is not part of these builds.',
                                  'Peak job commit includes all descendant processes and is kernel tracked. Live private memory and working-set sums are sampled once per second.',
                                  'Elapsed wall time includes process startup and up to one second of completion-polling granularity. Preparation/copying, baseline sampling and output verification are excluded.',
                                  'System CPU, paging, disk and available memory include other applications. Background workload was measured, not controlled.',
                                  'A single 64 GB workstation establishes observed usage and runtime, not a validated minimum hardware specification.']}
    (ROOT / 'benchmark_results.json').write_text(json.dumps(summary, indent=2) + '\n', encoding='utf-8')
    plt.rcParams.update({'font.size': 10, 'text.color': '#000032', 'axes.labelcolor': '#000032', 'axes.titlecolor': '#000032', 'xtick.color': '#000032', 'ytick.color': '#000032', 'figure.facecolor': 'white', 'axes.spines.top': False, 'axes.spines.right': False})
    fig, axes = plt.subplots(1, 2, figsize=(11, 4.2), layout='constrained')
    for product in ('hc', 'ta'):
        group = [row for row in ordered if row['product'] == product]
        if not group:
            continue
        x = [row['endpoints'] / 1000 for row in group]
        style = 'o-' if product == 'hc' else 's--'
        axes[0].plot(x, [row['metrics']['elapsed_seconds'] / 60 for row in group], style, label=NAMES[product], color=COLORS[product])
        axes[1].plot(x, [row['metrics']['peak_tree_commit_gib'] for row in group], style, label=NAMES[product], color=COLORS[product])
    for axis in axes:
        axis.set_xlabel('Synthetic endpoints (thousands)')
        axis.set_xticks([50,100,150,200,250,300])
        axis.set_ylim(bottom=0)
        axis.grid(alpha=.18)
        axis.legend()
    axes[0].set_ylabel('Elapsed minutes')
    axes[0].set_title('Full engine execution time')
    axes[1].set_ylabel('Peak process-tree committed memory (GiB)')
    axes[1].set_title('Kernel-tracked report memory demand')
    fig.savefig(ROOT / 'runtime_and_memory.png', dpi=170)
    plt.close(fig)
    fig, axes = plt.subplots(2, 1, figsize=(11, 6), layout='constrained')
    for product in ('hc', 'ta'):
        group = [row for row in ordered if row['product'] == product]
        if not group:
            continue
        x = [row['endpoints'] / 1000 for row in group]
        axes[0].plot(x, [row['metrics']['baseline_available_ram_gib'] for row in group], 'o--', label=NAMES[product] + ' before run', color=COLORS[product], alpha=.6)
        axes[0].plot(x, [row['metrics']['min_available_ram_gib'] for row in group], 's-', label=NAMES[product] + ' lowest during run', color=COLORS[product])
        axes[1].plot(x, [row['metrics']['baseline_cpu_percent'] for row in group], 'o--', label=NAMES[product] + ' background baseline', color=COLORS[product], alpha=.6)
        axes[1].plot(x, [row['metrics']['cpu_average_percent_machine'] for row in group], 's-', label=NAMES[product] + ' report process tree', color=COLORS[product])
    axes[0].set_ylabel('Available system RAM (GiB)')
    axes[1].set_ylabel('CPU, % of all logical processors')
    for axis in axes:
        axis.set_xlabel('Synthetic endpoints (thousands)')
        axis.grid(alpha=.18)
        axis.legend(ncol=2, fontsize=8)
    fig.savefig(ROOT / 'resource_context.png', dpi=170)
    plt.close(fig)
    figures = []
    for product in ('hc', 'ta'):
        candidate = selected.get((product, 300000))
        if not candidate:
            continue
        samples = [json.loads(line) for line in (Path(candidate['evidence_folder']) / 'resources.ndjson').read_text(encoding='utf-8').splitlines()]
        samples = [row for row in samples if row['phase'] in ('build', 'build_end')]
        fig, axes = plt.subplots(2, 1, figsize=(11, 5.8), sharex=True, layout='constrained')
        x = [row['elapsed_seconds'] / 60 for row in samples]
        axes[0].plot(x, [row['tree_private_bytes'] / 2**30 for row in samples], label='Live process-tree private memory', color=COLORS[product])
        axes[0].plot(x, [row['system_available_ram_bytes'] / 2**30 for row in samples], label='System available RAM', color='#7952b3')
        axes[1].plot(x, [row['tree_cpu_percent_machine'] for row in samples], label='Report process-tree CPU', color=COLORS[product])
        axes[1].plot(x, [row['system_cpu_percent'] for row in samples], label='Total system CPU', color='#7952b3', alpha=.65)
        axes[0].set_ylabel('GiB')
        axes[1].set_ylabel('% of all logical processors')
        axes[1].set_xlabel('Elapsed minutes')
        axes[0].set_title(NAMES[product] + ': 300k run resource changes')
        for axis in axes:
            axis.grid(alpha=.18)
            axis.legend(fontsize=8)
        name = f'{product}_300k_resource_trace.png'
        fig.savefig(ROOT / name, dpi=170)
        plt.close(fig)
        figures.append(name)

    def image(name):
        return f'<img alt="{html.escape(name)}" src="data:image/png;base64,{base64.b64encode((ROOT / name).read_bytes()).decode()}">'

    def table(headers, rows):
        return '<div class="scroll"><table><thead><tr>' + ''.join(f'<th>{html.escape(str(value))}</th>' for value in headers) + '</tr></thead><tbody>' + ''.join('<tr>' + ''.join(f'<td>{html.escape(str(value))}</td>' for value in row) + '</tr>' for row in rows) + '</tbody></table></div>'

    parts = ['<!doctype html><html><head><meta charset="utf-8"><title>Synthetic report benchmarks</title><style>body{font:16px/1.55 Segoe UI,Arial,sans-serif;color:#000032;background:#eef4f8;margin:0}main{max-width:1200px;background:white;margin:24px auto;padding:30px;border-radius:12px}h1,h2{color:#000032}h2{margin-top:32px}img{width:100%;height:auto}.scroll{overflow:auto}table{border-collapse:collapse;width:100%;font-size:13px}th,td{padding:9px;text-align:left;border-bottom:1px solid #d9e4ec;vertical-align:top}th{background:#eaf3f8}tbody tr:nth-child(even){background:#f6f9fc}.note{padding:16px;background:#fff5df;border-left:4px solid #b66c00}.small{font-size:13px}code{word-break:break-word}</style></head><body><main>',
             '<h1>Synthetic report execution benchmarks</h1><p>Measured on 20 October 2026. Times below use America/New_York. ' + ('All twelve builds passed output verification.' if complete else 'Benchmark collection is still in progress.') + '</p>',
             '<p class="note"><strong>Observed workstation baseline.</strong> These results support initial sizing guidance. They do not establish minimum CPU or RAM requirements on smaller machines. This is a source-Python engine benchmark; UI navigation, consultant review and opening Word are excluded.</p>']
    parts.append('<h2>Workstation and execution conditions</h2>')
    cpu = hardware['cpu'][0]
    ram = sum(module['Capacity'] for module in hardware['memory_modules']) / 2**30
    usable_ram = hardware['system']['TotalPhysicalMemory'] / 2**30
    disk = hardware['physical_disks'][0]
    parts.append(table(['Item', 'Recorded value'], [
        ['System', f"{hardware['system']['Manufacturer']} {hardware['system']['Model']}"],
        ['CPU', f"{cpu['Name']}; {cpu['NumberOfCores']} cores, {cpu['NumberOfLogicalProcessors']} logical processors"],
        ['RAM', f'{ram:.1f} GiB installed, {usable_ram:.1f} GiB OS-visible; 2 x 32 GiB, 4800 MT/s as reported by Windows'],
        ['Storage', f"{disk['FriendlyName']}; {disk['BusType']} {disk['MediaType']}; {disk['Size'] / 1e12:.2f} TB"],
        ['OS', f"{hardware['os']['Caption']}, build {hardware['os']['BuildNumber']}, {hardware['os']['OSArchitecture']}"],
        ['Graphics', '; '.join(adapter['Name'] + ' (driver ' + adapter['DriverVersion'] + ')' for adapter in (hardware.get('graphics', []) if isinstance(hardware.get('graphics', []), list) else [hardware['graphics']]))],
        ['Power', hardware['power_plan'][0]],
        ['Main revision / Python', f"{load(ROOT / 'hc_source_inventory.json')['commit']} / {runtime['hc']['python'].split()[0]}"],
        ['TA revision / Python', f"{load(ROOT / 'ta_source_inventory.json')['commit']} / {runtime['ta']['python'].split()[0]}"],
        ['Method', 'One measured pass at each size, one build at a time. All main runs precede TA. 15 seconds of background sampling before each build; one-second resource sampling. Windows caches not flushed.'],
    ]))
    parts.append('<h2>Execution time and memory</h2>')
    parts.append(table(['Product', 'Endpoints', 'Start (EDT)', 'Elapsed', 'Peak job commit (GiB)', 'Peak live private (GiB)', 'CPU avg. cores', 'Input / output (MiB)'], [
        [NAMES[row['product']], f"{row['endpoints']:,}", datetime.fromisoformat(row['started_utc']).astimezone(ZoneInfo('America/New_York')).strftime('%H:%M:%S'),
         f"{row['metrics']['elapsed_seconds'] / 60:.2f} min ({row['metrics']['elapsed_seconds']:.1f} s)", f"{row['metrics']['peak_tree_commit_gib']:.2f}", f"{row['metrics']['peak_tree_private_sampled_gib']:.2f}", f"{row['metrics']['cpu_average_core_equivalents']:.2f}",
         f"{sum(value['bytes'] for value in load(Path(row['evidence_folder']) / 'input_inventory.json').values()) / 2**20:.1f} / {row['verification']['output_bytes'] / 2**20:.1f}"] for row in ordered]))
    parts.append(image('runtime_and_memory.png'))
    parts.append('<h2>Resource pressure and background activity</h2>')
    parts.append(table(['Product / endpoints', 'Baseline available RAM (GiB)', 'Lowest available RAM (GiB)', 'Background CPU %', 'Report CPU %', 'Peak system commit %', 'System page reads/s p95', 'Disk queue p95'], [
        [f"{NAMES[row['product']]} / {row['endpoints']:,}", f"{row['metrics']['baseline_available_ram_gib']:.2f}", f"{row['metrics']['min_available_ram_gib']:.2f}", f"{row['metrics']['baseline_cpu_percent']:.1f}", f"{row['metrics']['cpu_average_percent_machine']:.1f}", f"{row['metrics']['system_commit_peak_percent']:.1f}", f"{row['metrics']['system_page_reads_p95_per_sec']:.1f}" if row['metrics']['system_page_reads_p95_per_sec'] is not None else 'Unavailable', f"{row['metrics']['system_disk_queue_p95']:.3f}" if row['metrics']['system_disk_queue_p95'] is not None else 'Unavailable'] for row in ordered]))
    parts.append('<p>Report CPU is normalized over all 20 logical processors: one fully used logical processor is approximately 5% of the machine. System counters include other applications. Paging activity alone does not prove the report is short of RAM. Working-set sums can count shared pages more than once; job commit is the principal peak memory measure.</p>')
    parts.append(image('resource_context.png'))
    for name in figures:
        parts.append(image(name))
    parts.append('<h2>Module timings</h2>')
    module_names = sorted({event['module'] for row in ordered for event in row['module_timings']})
    for product in ('hc', 'ta'):
        group = [row for row in ordered if row['product'] == product]
        if not group:
            continue
        parts.append('<h3>' + NAMES[product] + '</h3>')
        parts.append(table(['Module'] + [f"{row['endpoints'] // 1000}k (s)" for row in group], [[MODULE_NAMES.get(module, module)] + [f"{next((event['seconds'] for event in row['module_timings'] if event['module'] == module), 0):.1f}" for row in group] for module in module_names if any(event['module'] == module for row in group for event in row['module_timings'])]))
    parts.append('<h2>What this supports for user guidance</h2>')
    if ordered:
        peak = max(row['metrics']['peak_tree_commit_gib'] for row in ordered)
        headroom = min(row['metrics']['min_available_ram_gib'] for row in ordered)
        allowance = peak * 1.5 + 6
        trial_ram = next((amount for amount in (16, 32, 64, 128) if amount >= allowance), math.ceil(allowance / 32) * 32)
        parts.append(f'<p>The largest observed report-process allocation was <strong>{peak:.2f} GiB committed</strong>. The workstation retained at least <strong>{headroom:.2f} GiB available physical RAM</strong> during the measured builds. Keep the report allocation separate from Windows and other applications when planning RAM.</p>')
        parts.append(f'<p>For an initial operating allowance, aim to have about <strong>{math.ceil(peak * 1.5)} GiB of available RAM before the largest build</strong>. This applies a 50% margin to the observed report peak; it is a planning allowance rather than a validated pass/fail gate. Check available RAM after the desktop tool has scanned the selected dataset and other required applications are open, since the desktop UI is outside this measured process tree.</p>')
        parts.append(f'<p>A <strong>{trial_ram} GB machine is a reasonable next validation target</strong>, using a planning allowance of 1.5 times observed peak report commit plus 6 GiB for Windows and lightweight background activity. This is an explicit planning assumption, not a tested minimum or a commitment that every {trial_ram} GB machine will run these workloads comfortably. Allow more RAM for browsers, consoles, other tools, larger captures or concurrent report builds.</p>')
        parts.append('<p>For CPU guidance, publish these observed runtimes with the measured CPU model and logical processor count. These runs do not compare different processors or prove a minimum core count. Use local SSD storage and retain space for inputs, intermediate files and final outputs; output sizes in the table exclude temporary files that the engine cleans up.</p>')
    parts.append('<h2>Scope, validation and limits</h2><ul>' + ''.join('<li>' + html.escape(text) + '</li>' for text in summary['interpretation']) + '</ul>')
    parts.append('<p>Main includes deployment overview, health dashboard, SQL database information, FillDB, PerfMon, Client Performance, capacity, deployment information, client settings suggestions, server logs, findings, release intelligence, strengths, key risks and supporting analysis. The separate scorecard-refresh workflow is excluded because findings generates the review/scoring workflow during this full build. Automated findings are left unreviewed for this timing exercise.</p>')
    parts.append('<p>Output verification checks every selected module completed, DOCX ZIP/XML integrity, expected workbook/chart outputs, current client-data worksheet coverage and the exact reporting-row count in the client workbook. Verification occurs after timing. It does not certify consultant-reviewed findings or visual layout on every Word page.</p>')
    if summary['excluded_attempts']:
        parts.append('<p>Excluded setup attempts: ' + html.escape('; '.join(f"{row['product']} {row['endpoints']:,}, attempt {row['attempt']}, exit {row['exit_code']}" for row in summary['excluded_attempts'])) + '. The first main setup attempt omitted a required input path and stopped before running any report module. It is retained separately and contributes no valid benchmark timing.</p>')
    parts.append('<h2>Evidence files</h2><p><code>C:\\Temp\\B20</code> contains this report, PNG charts, benchmark_results.json, hardware.json, per-product runtime and code inventories, and fixed source snapshots. Each product/size/attempt folder retains config.json, input_inventory.json, resources.ndjson (one-second samples), module_events.ndjson, console.log, result.json and generated reports under out.</p></main></body></html>')
    (ROOT / 'Benchmark_Report.html').write_text('\n'.join(parts), encoding='utf-8')
    lines = ['Synthetic report benchmarks: 20 October 2026', f'Complete: {complete}',
             f"CPU: {cpu['Name']}, {cpu['NumberOfCores']} cores / {cpu['NumberOfLogicalProcessors']} logical", f'Installed RAM: {ram:.1f} GiB',
             'Product | Endpoints | Seconds | Peak job commit GiB | Minimum system available GiB']
    lines += [f"{row['product']} | {row['endpoints']} | {row['metrics']['elapsed_seconds']:.1f} | {row['metrics']['peak_tree_commit_gib']:.2f} | {row['metrics']['min_available_ram_gib']:.2f}" for row in ordered]
    lines += ['', 'See Benchmark_Report.html for methodology, resource trends and provisional user guidance.', 'These are observed source-engine measurements on one 64 GB workstation, not proven minimum requirements.']
    (ROOT / 'Benchmark_Summary.txt').write_text('\n'.join(lines) + '\n', encoding='utf-8')
    print('\n'.join(lines), flush=True)


if __name__ == '__main__':
    main()
