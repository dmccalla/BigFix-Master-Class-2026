"""Check completed evidence and the portable HTML report after benchmark execution."""
import json
from pathlib import Path
import subprocess
from PIL import Image
from playwright.sync_api import sync_playwright

root = Path('C:/Temp/B20')
summary = json.loads((root / 'benchmark_results.json').read_text(encoding='utf-8'))
assert summary['complete'] and len(summary['valid_runs']) == 12
assert all(row['valid'] and row['verification']['passed'] for row in summary['valid_runs'])
assert len(summary['input_comparisons']) == 6
assert all(row['identical_inputs_across_products'] for row in summary['input_comparisons'])
environment = {}
for product in ('hc', 'ta'):
    before = json.loads((root / f'{product}_runtime.json').read_text(encoding='utf-8'))
    captured = subprocess.run([before['executable'], str(Path(__file__).with_name('benchmark_runtime_inventory.py')), '--runtime'], capture_output=True, text=True, check=True)
    after = json.loads(captured.stdout)
    (root / f'{product}_runtime_after.json').write_text(json.dumps(after, indent=2), encoding='utf-8')
    environment[product] = {'python_unchanged': before['python'] == after['python'], 'packages_unchanged': before['packages'] == after['packages']}
    app = root / ('src/hc/Report Builder' if product == 'hc' else 'src/ta')
    checked = subprocess.run(['git', '-C', str(app), 'diff', '--quiet'], capture_output=True)
    environment[product]['snapshot_tracked_files_unchanged'] = checked.returncode == 0
(root / 'environment_verification.json').write_text(json.dumps(environment, indent=2), encoding='utf-8')
assert all(all(result.values()) for result in environment.values()), environment
for name in ('runtime_and_memory.png', 'resource_context.png', 'hc_300k_resource_trace.png', 'ta_300k_resource_trace.png'):
    with Image.open(root / name) as image:
        image.verify()
errors = []
with sync_playwright() as playwright:
    browser = None
    for channel in ('msedge', 'chrome'):
        try:
            browser = playwright.chromium.launch(channel=channel, headless=True)
            break
        except Exception:
            continue
    assert browser is not None, 'No installed browser available for report verification'
    try:
        page = browser.new_page(viewport={'width': 1440, 'height': 1100}, device_scale_factor=1)
        page.on('pageerror', lambda error: errors.append(str(error)))
        page.goto((root / 'Benchmark_Report.html').as_uri(), wait_until='load')
        page.evaluate('document.fonts.ready')
        assert page.locator('h1').inner_text() == 'Synthetic report execution benchmarks'
        assert page.locator('table').count() >= 5
        assert page.evaluate('Array.from(document.images).every(image => image.complete && image.naturalWidth > 0)')
        assert page.evaluate('document.documentElement.scrollWidth <= window.innerWidth + 2')
        page.screenshot(path=str(root / 'Benchmark_Report_preview.png'))
        page.get_by_role('heading', name='Execution time and memory', exact=True).scroll_into_view_if_needed()
        page.screenshot(path=str(root / 'Benchmark_Results_preview.png'))
        assert not errors, errors
    finally:
        browser.close()
(root / 'report_verification.json').write_text(json.dumps({'passed': True, 'verified_runs': 12, 'input_pairs_identical': 6, 'html_image_checks': True, 'browser_errors': errors}, indent=2), encoding='utf-8')
print('All 12 runs verified; six identical input pairs; HTML and plots verified.')
